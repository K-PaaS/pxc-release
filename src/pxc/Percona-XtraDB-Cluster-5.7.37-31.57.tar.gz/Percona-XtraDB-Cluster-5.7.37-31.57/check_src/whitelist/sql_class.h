< #define WSREP_BINLOG_FORMAT(my_format) my_format
<
< #define CF_SKIP_WSREP_CHECK     0
