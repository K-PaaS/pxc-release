> #if defined(__sparc) && (defined(__SUNPRO_CC) || defined(__SUNPRO_C))
> #define STACK_MULTIPLIER 2UL
> #else
> #endif
