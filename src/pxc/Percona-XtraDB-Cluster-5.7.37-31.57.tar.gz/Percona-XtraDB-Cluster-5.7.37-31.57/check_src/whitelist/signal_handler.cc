<     "Please help us make Percona XtraDB Cluster better by reporting any\n"
<     "bugs at https://jira.percona.com/projects/PXC/issues\n\n");
>     "Please help us make Percona Server better by reporting any\n"
>     "bugs at https://bugs.percona.com/\n\n");
<     "You may download the Percona XtraDB Cluster operations manual by visiting\n"
<     "http://www.percona.com/software/percona-xtradb-cluster/. You may find information\n"
>     "You may download the Percona Server operations manual by visiting\n"
>     "http://www.percona.com/software/percona-server/. You may find information\n"
