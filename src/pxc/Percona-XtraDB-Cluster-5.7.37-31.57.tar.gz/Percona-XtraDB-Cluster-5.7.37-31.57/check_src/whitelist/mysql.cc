<          "Percona XtraDB Cluster manual: http://www.percona.com/doc/percona-xtradb-cluster/5.7/\n"
>            "Percona Server manual: http://www.percona.com/doc/percona-server/%d.%d\n"
