< @param[in] add_to_hash	If the lock should be added to the hash table
< @param[in,out] c_lock	conflicting lock
< @param[in,out] thr	query thread handler */
> @param[in] add_to_hash	If the lock should be added to the hash table */
< @param[in,out] c_lock		conflicting lock
< @param[in,out] thr		query thread handler
