< #define WSREP_BINLOG_FORMAT(my_format) my_format
