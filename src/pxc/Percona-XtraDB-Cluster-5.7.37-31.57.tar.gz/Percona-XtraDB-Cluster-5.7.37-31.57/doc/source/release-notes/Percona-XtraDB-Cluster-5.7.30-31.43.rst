.. _PXC-5.7.30-31.43:

================================================================================
*Percona XtraDB Cluster* 5.7.30-31.43
================================================================================

:Date: June 25, 2020
:Installation: `Installing Percona XtraDB Cluster <https://www.percona.com/doc/percona-xtradb-cluster/5.7/install/index.html>`_

Bugs Fixed
================================================================================

* :jirabug:`PXC-3170`: Backport PXC-3154 - Thread pooling could hang on shutdown
* :jirabug:`PXC-3165`: Allow COM_FIELD_LIST to be executed when WSREP was not ready


