.. _PXC-5.7.31-31.45.3:

================================================================================
*Percona XtraDB Cluster* 5.7.31-31.45.3
================================================================================

:Date: October 22, 2020
:Installation: `Installing Percona XtraDB Cluster  <https://www.percona.com/doc/percona-xtradb-cluster/5.7/install/index.html>`_

Bugs Fixed
================================================================================

* :jirabug:`PXC-3456`: Allow specific characters in SST method names and SST request data.