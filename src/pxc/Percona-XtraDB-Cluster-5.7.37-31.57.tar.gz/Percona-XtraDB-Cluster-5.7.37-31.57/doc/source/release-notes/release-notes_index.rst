============================================
 |Percona XtraDB Cluster| 5.7 Release notes
============================================

.. toctree::
   :maxdepth: 1

   Percona-XtraDB-Cluster-5.7.36-31.55
   Percona-XtraDB-Cluster-5.7.35-31.53
   Percona-XtraDB-Cluster-5.7.34-31.51
   Percona-XtraDB-Cluster-5.7.33-31.49
   Percona-XtraDB-Cluster-5.7.32-31.47
   Percona-XtraDB-Cluster-5.7.31-31-45.3
   Percona-XtraDB-Cluster-5.7.31-31.45.2
   Percona-XtraDB-Cluster-5.7.31-31.45
   Percona-XtraDB-Cluster-5.7.30-31.43
   Percona-XtraDB-Cluster-5.7.29-31.43
   Percona-XtraDB-Cluster-5.7.28-31.41.2
   Percona-XtraDB-Cluster-5.7.28-31.41
   Percona-XtraDB-Cluster-5.7.27-31.39
   Percona-XtraDB-Cluster-5.7.26-31.37
   Percona-XtraDB-Cluster-5.7.25-31.35
   Percona-XtraDB-Cluster-5.7.24-31.33
   Percona-XtraDB-Cluster-5.7.23-31.31.2
   Percona-XtraDB-Cluster-5.7.23-31.31
   Percona-XtraDB-Cluster-5.7.22-29.26
   Percona-XtraDB-Cluster-5.7.21-29.26
   Percona-XtraDB-Cluster-5.7.20-29.24
   Percona-XtraDB-Cluster-5.7.19-29.22-3
   Percona-XtraDB-Cluster-5.7.19-29.22
   Percona-XtraDB-Cluster-5.7.18-29.20
   Percona-XtraDB-Cluster-5.7.17-29.20
   Percona-XtraDB-Cluster-5.7.17-27.20
   Percona-XtraDB-Cluster-5.7.16-27.19
   Percona-XtraDB-Cluster-5.7.14-26.17
   Percona-XtraDB-Cluster-5.7.12-5rc1-26.16
   Percona-XtraDB-Cluster-5.7.11-4beta-25.14.2
