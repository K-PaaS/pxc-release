.. _PXC-5.7.31-31.45.2:

================================================================================
*Percona XtraDB Cluster* 5.7.31-31.45.2
================================================================================

:Date: October 9, 2020
:Installation: `Installing Percona XtraDB Cluster <https://www.percona.com/doc/percona-xtradb-cluster/5.7/install/index.html>`_

This release fixes the security vulnerability `CVE-2020-15180 <https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2020-15180>`_

